+-------------------------------------------------------+
| * The CODE                                            |
|   - src/tree.cpp: contains the red black              |
|     tree operations                                   |
|   - src/main.cpp: entry point of the program          |
|   - src/utils.cpp: constains code used to sim the     |
|     runtimes                                          |
|                                                       |
| * Running                                             |
|   - run 'make clean' to remove any build files        |
|   - run 'make' to compile the code                    |
|   - run './program.o' to run the code                 |
+-------------------------------------------------------+
